#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif // WX_PRECOMP

#include <string>
#include <wx/spinctrl.h>

class frameTram : public wxFrame
{
public:
    frameTram(int dureeSimulationParDefaut);
private:

    std::string d_cheminFichier;
    int d_dureeSimulation;
    int d_dureeSimulationParDefaut;

    wxTextCtrl* texteFichier; //Pour avoir acc�s � l'affichage du chemin du fichier
    wxSpinCtrl* modificationDuree; //Affichage de la dur�e de la simulation
    wxFileDialog* openFileDialog; //Ouvre une fen�tre de choix de ficiers
    void OnQuit(wxCommandEvent &e); //Quitter l'application
    void OnReset(wxCommandEvent &e); //Remet par d�faut toutes les valeurs de d�part
    void OnStart(wxCommandEvent &e); //Lance la simulation
    void OnBrowse(wxCommandEvent &e); //Ouvre une fen�tre de dialogque pour aller chercher le fichier texte
    void OnLoad(wxCommandEvent &e); //Charge les donn�es contenues dans le fichier texte dans les variables des classes appropri�es
    void OnTimeChange(wxCommandEvent &e); //Change le compteur que l'utilisateur modifie la dur�e de l'ex�cution de l'application

    //Mises � jour des affichages
    void MAJCheminFichier();
    void MAJDuree();
};
