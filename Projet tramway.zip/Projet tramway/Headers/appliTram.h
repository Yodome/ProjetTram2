#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif // WX_PRECOMP

class appliTram : public wxApp
{
public:
    virtual bool OnInit();
};

