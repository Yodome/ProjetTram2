#include "../Headers/appliTram.h"
#include "../Headers/frameTram.h"
#include "../Headers/Arret.h"
#include "../Headers/File.h"
#include "../Headers/Ligne.h"
#include "../Headers/Liste.h"
#include "../Headers/Position.h"
#include "../Headers/Tram.h"
#include "../Headers/graphics.h"

IMPLEMENT_APP(appliTram)

bool appliTram::OnInit(){
    auto c = new frameTram(60);
    c->Show(true);
    return true;
}
